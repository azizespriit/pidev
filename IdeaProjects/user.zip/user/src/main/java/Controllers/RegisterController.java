package Controllers;

import entites.Client;
import entites.Admin;
import entites.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import services.ClientServiceImpl;
import services.AdminServiceImpl;
import services.UserServiceImpl;

public class RegisterController {

  @FXML
  private TextField CinTextFiled;
  @FXML
  private CheckBox FemmeCheckBox;
  @FXML
  private CheckBox HommeCheckBox;
  @FXML
  private TextField NomTextFiled;
  @FXML
  private CheckBox ClientCheckBox;
  @FXML
  private TextField PasswordTextFiled;

  @FXML
  private TextField PhoneTextFiled;

  @FXML
  private TextField PrenomTextFiled;

  @FXML
  private TextField emailTextFiled;

  @FXML
  private Label YearsOfExperienceLabel;

  @FXML
  private TextField YearsOfExperienceTextField;

  @FXML
  private Label EventsOrganizedLabel;

  @FXML
  private TextField EventsOrganizedTextField;

  @FXML
  private Button ClientButton;

  @FXML
  private Button AdminButton;


  @FXML
  private CheckBox AdminCheckBox;

  @FXML
  private Label SpecialtyLabel;

  @FXML
  private TextField SpecialtyTextField;

  @FXML
  private Label experienceLabel;

  @FXML
  private TextField experienceTextField;


  // Méthode d'inscription pour l'utilisateur (et l'Client si sélectionné)
  @FXML
  void register(ActionEvent event) {
    // Récupérer les valeurs des champs
    String cin = CinTextFiled.getText().trim();
    String lastName = NomTextFiled.getText().trim();
    String firstName = PrenomTextFiled.getText().trim();
    String gender = getGender();
    String phone = PhoneTextFiled.getText().trim();
    String roles = getRoles(); // Ici on suppose que les rôles sont gérés avec une valeur "Client" ou autre

    String email = emailTextFiled.getText().trim();
    String password = PasswordTextFiled.getText().trim();

    // Vérification des champs
    if (cin.isEmpty() || lastName.isEmpty() || firstName.isEmpty() || gender.isEmpty() || phone.isEmpty() || email.isEmpty() || password.isEmpty()) {
      showAlert("Erreur", "Tous les champs doivent être remplis.", AlertType.ERROR);
      return;
    }

    // Créer l'objet User
    User user = new User(cin, lastName, firstName, gender, phone, roles, email, password);

    // Appel au service User pour enregistrer l'utilisateur commun
    UserServiceImpl userService = new UserServiceImpl();
    try {
      userService.register(user);

      // Si l'utilisateur est un Client, on enregistre les informations spécifiques
      if (ClientCheckBox.isSelected()) {
        registerClient(user);
      }

      // Si l'utilisateur est un admin, on enregistre les informations spécifiques
      if (AdminCheckBox.isSelected()) {
        registerAdmin(user);
      }

      showAlert("Succès", "Utilisateur enregistré avec succès !", AlertType.INFORMATION);
    } catch (Exception e) {
      System.err.println("Erreur lors de l'enregistrement : " + e.getMessage());
      showAlert("Erreur", "Une erreur est survenue lors de l'enregistrement. Veuillez réessayer.", AlertType.ERROR);
    }
  }

  // Méthode pour récupérer le genre sélectionné
  private String getGender() {
    if (FemmeCheckBox.isSelected()) {
      return "Femme";
    } else if (HommeCheckBox.isSelected()) {
      return "Homme";
    }
    return ""; // Si aucun genre n'est sélectionné, retourner une chaîne vide
  }

  // Méthode pour récupérer le rôle sélectionné (seulement "Client" dans ce cas)
  private String getRoles() {
    if (ClientCheckBox.isSelected()) {
      return "Client";
    }
    if (AdminCheckBox.isSelected()) {
      return "admin";
    }
    return ""; // Si l'option n'est pas cochée, le rôle est vide ou "utilisateur" par défaut
  }

  // Méthode pour enregistrer un Client dans la base de données
  private void registerClient(User user) {
    try {
      // Assurez-vous que les champs spécifiques à l'Client sont remplis
      int yearsOfExperience = Integer.parseInt(YearsOfExperienceTextField.getText().trim());
      int eventsOrganized = Integer.parseInt(EventsOrganizedTextField.getText().trim());

      Client Client = new Client(
              user.getCin(), user.getLastName(), user.getFirstName(),
              user.getGender(), user.getPhone(), user.getRoles(),
              user.getEmail(), user.getPassword(),
              yearsOfExperience, eventsOrganized
      );

      // Appeler le service Client pour enregistrer l'Client
      ClientServiceImpl ClientService = new ClientServiceImpl();
      ClientService.registerClient(Client);
    } catch (Exception e) {
      showAlert("Erreur", "Erreur lors de l'enregistrement de l'Client.", AlertType.ERROR);
      e.printStackTrace();
    }
  }

  // Méthode pour enregistrer un admin dans la base de données
  private void registerAdmin(User user) {
    try {
      // Assurez-vous que les champs spécifiques au admin sont remplis
      String specialty = SpecialtyTextField.getText().trim();
      String serviceDescription = experienceTextField.getText().trim();

      Admin admin = new Admin(
              user.getCin(), user.getLastName(), user.getFirstName(),
              user.getGender(), user.getPhone(), user.getRoles(),
              user.getEmail(), user.getPassword(),
              specialty, serviceDescription
      );

      // Appeler le service Admin pour enregistrer le admin
      AdminServiceImpl adminService = new AdminServiceImpl();
      adminService.registerAdmin(admin);
    } catch (Exception e) {
      showAlert("Erreur", "Erreur lors de l'enregistrement du admin.", AlertType.ERROR);
      e.printStackTrace();
    }
  }

  // Méthode pour afficher une alerte
  private void showAlert(String title, String message, AlertType alertType) {
    Alert alert = new Alert(alertType);
    alert.setTitle(title);
    alert.setHeaderText(null);
    alert.setContentText(message);
    alert.showAndWait();
  }

  // Méthode pour gérer l'affichage des champs spécifiques à l'Client
  @FXML
  public void handleClientCheckBox(ActionEvent event) {
    if (ClientCheckBox.isSelected()) {
      AdminCheckBox.setSelected(false);
      // Afficher les champs spécifiques à l'Client
      YearsOfExperienceLabel.setVisible(true);
      YearsOfExperienceTextField.setVisible(true);
      EventsOrganizedLabel.setVisible(true);
      EventsOrganizedTextField.setVisible(true);
      ClientButton.setVisible(true);

      // Cacher les champs spécifiques au admin
      SpecialtyLabel.setVisible(false);
      SpecialtyTextField.setVisible(false);
      experienceLabel.setVisible(false);
      experienceTextField.setVisible(false);
      AdminButton.setVisible(false);
    } else {
      // Cacher les champs spécifiques à l'Client
      YearsOfExperienceLabel.setVisible(false);
      YearsOfExperienceTextField.setVisible(false);
      EventsOrganizedLabel.setVisible(false);
      EventsOrganizedTextField.setVisible(false);
      ClientButton.setVisible(false);
    }
  }

  // Méthode pour gérer l'action du bouton "S'inscrire en tant qu'Client"
  @FXML
  private void handleClientButtonClick(ActionEvent event) {
    // Cette méthode est appelée lorsque l'utilisateur clique sur le bouton "S'inscrire en tant que Client"

    // Vérifiez si tous les champs nécessaires sont remplis
    String yearsOfExperienceText = YearsOfExperienceTextField.getText().trim();
    String eventsOrganizedText = EventsOrganizedTextField.getText().trim();

    if (yearsOfExperienceText.isEmpty() || eventsOrganizedText.isEmpty()) {
      showAlert("Erreur", "Les champs spécifiques à l'Client doivent être remplis.", AlertType.ERROR);
      return;
    }

    try {
      // Récupérer les données spécifiques à l'Client
      int yearsOfExperience = Integer.parseInt(yearsOfExperienceText);
      int eventsOrganized = Integer.parseInt(eventsOrganizedText);

      // Appel à la méthode d'inscription pour enregistrer l'Client
      // Créer un objet Client
      Client Client = new Client(
              CinTextFiled.getText().trim(),
              NomTextFiled.getText().trim(),
              PrenomTextFiled.getText().trim(),
              getGender(),
              PhoneTextFiled.getText().trim(),
              getRoles(),
              emailTextFiled.getText().trim(),
              PasswordTextFiled.getText().trim(),
              yearsOfExperience,
              eventsOrganized
      );

      // Appeler le service pour enregistrer l'Client
      ClientServiceImpl ClientService = new ClientServiceImpl();
      ClientService.registerClient(Client);

      // Afficher un message de succès
      showAlert("Succès", "Client inscrit avec succès !", AlertType.INFORMATION);

    } catch (Exception e) {
      showAlert("Erreur", "Une erreur est survenue lors de l'inscription de l'Client.", AlertType.ERROR);
      e.printStackTrace();
    }
  }

  // Méthode pour gérer l'affichage des champs spécifiques au Admin
  @FXML
  public void handleAdminCheckBox(ActionEvent event) {
    if (AdminCheckBox.isSelected()) {
      ClientCheckBox.setSelected(false);
      // Afficher les champs spécifiques au admin
      SpecialtyLabel.setVisible(true);
      SpecialtyTextField.setVisible(true);
      experienceLabel.setVisible(true);
      experienceTextField.setVisible(true);
      AdminButton.setVisible(true);

      // Cacher les champs spécifiques à l'Client
      YearsOfExperienceLabel.setVisible(false);
      YearsOfExperienceTextField.setVisible(false);
      EventsOrganizedLabel.setVisible(false);
      EventsOrganizedTextField.setVisible(false);
      ClientButton.setVisible(false);
    } else {
      // Cacher les champs spécifiques au admin
      SpecialtyLabel.setVisible(false);
      SpecialtyTextField.setVisible(false);
      experienceLabel.setVisible(false);
      experienceTextField.setVisible(false);
      AdminButton.setVisible(false);
    }

  }

  // Méthode pour gérer l'action du bouton "S'inscrire en tant que Admin"
  @FXML
  private void handleAdminButtonClick(ActionEvent event) {
    // Cette méthode est appelée lorsque l'utilisateur clique sur le bouton "S'inscrire en tant que Admin"

    // Vérifiez si tous les champs nécessaires sont remplis
    String specialtyText = SpecialtyTextField.getText().trim();
    String serviceDescriptionText = experienceTextField.getText().trim();

    if (specialtyText.isEmpty() || serviceDescriptionText.isEmpty()) {
      showAlert("Erreur", "Les champs spécifiques au admin doivent être remplis.", AlertType.ERROR);
      return;
    }

    try {
      // Récupérer les données spécifiques au admin
      String specialty = specialtyText;
      String serviceDescription = serviceDescriptionText;

      // Créer un objet Admin
      Admin admin = new Admin(
              CinTextFiled.getText().trim(),
              NomTextFiled.getText().trim(),
              PrenomTextFiled.getText().trim(),
              getGender(),
              PhoneTextFiled.getText().trim(),
              getRoles(),
              emailTextFiled.getText().trim(),
              PasswordTextFiled.getText().trim(),
              specialty,
              serviceDescription
      );

      // Appeler le service pour enregistrer le admin
      AdminServiceImpl adminService = new AdminServiceImpl();
      adminService.registerAdmin(admin);

      // Afficher un message de succès
      showAlert("Succès", "Admin inscrit avec succès !", AlertType.INFORMATION);

    } catch (Exception e) {
      showAlert("Erreur", "Une erreur est survenue lors de l'inscription du admin.", AlertType.ERROR);
      e.printStackTrace();
    }
  }
}
