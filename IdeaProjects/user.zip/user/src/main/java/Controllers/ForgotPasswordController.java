package Controllers;

import entites.EmailSender;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;
import services.UserServiceImpl;
import utils.dataSource;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;

public class ForgotPasswordController {

    @FXML
    private TextField emailField;

    @FXML
    private TextField codeField;

    @FXML
    private Label messageLabel;

    @FXML
    private PasswordField newPasswordField;

    @FXML
    private PasswordField confirmPasswordField;


    private String generateResetCode() {
        Random random = new Random();
        int code = 100000 + random.nextInt(900000); // Generates a 6-digit code
        return String.valueOf(code);
    }

    @FXML
    private void handleSendResetLink( ActionEvent event) throws IOException {
        String email = emailField.getText().trim();

        // ✅ Validate Email
        if (!isValidEmail(email)) {
            messageLabel.setText("Veuillez entrer un email valide.");
            messageLabel.setVisible(true);
            return;
        }

        // ✅ Generate Reset Code
        String resetCode = generateResetCode();

        // ✅ Store the Reset Code in Database
        UserServiceImpl userService = new UserServiceImpl();
        if (userService.storeResetCodeInDB(email, resetCode)) {
            // ✅ Send Email with the Code
            String subject = "Réinitialisation de votre mot de passe";
            String messageText = "Votre code de réinitialisation : " + resetCode;
            EmailSender emailSender = new EmailSender();
            boolean sent = emailSender.sendEmail(email, subject, messageText);

            if (sent) {
                messageLabel.setText("Code envoyé avec succès !");
                messageLabel.setStyle("-fx-text-fill: green;");
                loadFXML("/EnterResetCode.fxml",event);
            } else {
                messageLabel.setText("Échec de l'envoi de l'email.");
                messageLabel.setStyle("-fx-text-fill: red;");
            }
        } else {
            messageLabel.setText("Erreur lors de la mise à jour du code.");
            messageLabel.setStyle("-fx-text-fill: red;");
        }
        messageLabel.setVisible(true);
    }


    private boolean isValidEmail(String email) {
        return email.matches("^[A-Za-z0-9+_.-]+@(.+)$"); // Basic email validation
    }

    private void loadFXML(String fxmlFile, ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
        Parent root = loader.load();
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }


    public void handleVerifyCode(ActionEvent actionEvent) throws IOException {
        String codeToVerify = codeField.getText().trim();

        // Retrieve the last inserted code from the database
        UserServiceImpl userService = new UserServiceImpl();
        String lastCode = userService.getLastGeneratedCodeFromDB();

        if (lastCode != null && lastCode.equals(codeToVerify)) {
            messageLabel.setText("Code valide ! Veuillez entrer votre nouveau mot de passe.");
            messageLabel.setStyle("-fx-text-fill: green;");
            loadFXML("/SetNewPassword.fxml", actionEvent);
        } else {
            messageLabel.setText("Code invalide. Veuillez réessayer.");
            messageLabel.setStyle("-fx-text-fill: red;");
        }

        messageLabel.setVisible(true);
    }

    public void handleChangePassword(ActionEvent actionEvent) {
        String newPass = newPasswordField.getText().trim();
        String confirmNewPass = confirmPasswordField.getText().trim();

        // Validate password fields
        if (newPass.isEmpty() || confirmNewPass.isEmpty()) {
            messageLabel.setText("Veuillez remplir tous les champs.");
            messageLabel.setStyle("-fx-text-fill: red;");
            messageLabel.setVisible(true);
            return;
        }

        if (!newPass.equals(confirmNewPass)) {
            messageLabel.setText("Les mots de passe ne correspondent pas.");
            messageLabel.setStyle("-fx-text-fill: red;");
            messageLabel.setVisible(true);
            return;
        }

        // Update password in the database
        UserServiceImpl userService = new UserServiceImpl();
        String email = userService.getLastEmailFromDB();
        boolean updated = userService.updatePasswordInDB(email, newPass); // Assuming you have the user's email stored

        if (updated) {
            messageLabel.setText("Mot de passe modifié avec succès !");
            messageLabel.setStyle("-fx-text-fill: green;");
        } else {
            messageLabel.setText("Échec de la modification du mot de passe.");
            messageLabel.setStyle("-fx-text-fill: red;");
        }
        messageLabel.setVisible(true);
    }

}
