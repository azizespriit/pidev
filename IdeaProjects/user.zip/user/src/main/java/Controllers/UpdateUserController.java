package Controllers;

import entites.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import services.UserServiceImpl;
import javafx.fxml.FXMLLoader;

import java.io.IOException;

//import static com.sun.tools.javac.jvm.ByteCodes.ret;

public class UpdateUserController {

    public TextField genderField;
    public TextField PasswordField;
    @FXML
    private TextField firstNameField;

    @FXML
    private TextField lastNameField;

    @FXML
    private TextField emailField;

    @FXML
    private Button updateButton;

    @FXML
    private TextField idField;

    public int idUser;
    private final UserServiceImpl userService = new UserServiceImpl();
    private User user = new User();

    @FXML
    public void initialize() {
        updateButton.setOnAction(event -> updateUser());
        idField.setText(String.valueOf(this.idUser));
    }

    @FXML
    public void setUserId(int id){
        idField.setText(String.valueOf(id));
    }

    @FXML
    private void updateUser() {
        // Validate input fields
        if (firstNameField.getText().isEmpty() || lastNameField.getText().isEmpty() || emailField.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Tous les champs doivent être remplis.");
            return;
        }


        user.setIdUser(Integer.parseInt(idField.getText()));
        user.setFirstName(firstNameField.getText());
        user.setLastName(lastNameField.getText());
        user.setEmail(emailField.getText());
        System.out.println(user);
        boolean success = userService.updateUser(user);
        if (success) {
            showAlert(Alert.AlertType.INFORMATION, "Succès", "Utilisateur mis à jour avec succès.");
        } else {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de mettre à jour l'utilisateur.");
        }
    }


    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void loadFXML(String fxmlFile, ActionEvent event, int userId) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
        Parent root = loader.load();

        // Get the controller of the loaded FXML
        UpdateUserController controller = loader.getController();

        // Set the user ID in a TextField or other UI elements
        controller.setUserId(userId);

        // Get the current stage and show the new scene
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }


    public void handleUpdate(ActionEvent event) throws IOException {
        loadFXML("/UpdateUser.fxml", event, idUser);
        System.out.println(this.idUser);
    }



}
