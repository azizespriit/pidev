package Controllers;

import entites.Sessions;
import entites.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;
import services.UserServiceImpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainController {

  @FXML
  private AnchorPane mainContent;

  @FXML
  private TableView<User> userTable;

  @FXML
  private TableColumn<User, Void> deleteColumn; // Delete button column
  @FXML
  private TableColumn<User, Void> updateColumn;

  private final UserServiceImpl userService = new UserServiceImpl();

  @FXML
  public void initialize() {
    loadUserProfile();
    loadUserData(); // Load table content when initializing
    addDeleteButtonToTable(); // Add delete button dynamically
    addUpdateButtonToTable();
  }

  @FXML
  private void handleButtonAction(ActionEvent event) {
    Button clickedButton = (Button) event.getSource();
    String fxmlFile = switch (clickedButton.getText()) {
      case "Événements" -> "/DashboardFront/Evenements.fxml";
      case "Services" -> "/DashboardFront/Services.fxml";
      case "Produits" -> "/DashboardFront/Produits.fxml";
      case "Équipements" -> "/DashboardFront/Equipements.fxml";
      case "Reserver Équipements" -> "/DashboardFront/Reservation.fxml";
      case "Panier" -> "/DashboardFront/Panier.fxml";
      case "Réclamation" -> "/DashboardFront/Reclamation.fxml";
      default -> "";
    };

    if (!fxmlFile.isEmpty()) {
      loadContent(fxmlFile);
    }
  }

  private void loadContent(String fxmlFile) {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
      Parent newContent = loader.load();
      mainContent.getChildren().setAll(newContent);
      AnchorPane.setTopAnchor(newContent, 0.0);
      AnchorPane.setBottomAnchor(newContent, 0.0);
      AnchorPane.setLeftAnchor(newContent, 0.0);
      AnchorPane.setRightAnchor(newContent, 0.0);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  private void loadFXML(String fxmlFile, ActionEvent event) throws IOException {
    FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
    Parent root = loader.load();
    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    stage.setScene(new Scene(root));
    stage.show();
  }

  public void handleLogout(ActionEvent event) throws IOException {
    String username = Sessions.getCurrentUser().getFirstName();
    Sessions.logout();
    showAlert("Déconnexion", "L'utilisateur " + username + " a été déconnecté avec succès.");
    loadFXML("/login.fxml", event);
  }

  private void showAlert(String title, String message) {
    Alert alert = new Alert(Alert.AlertType.INFORMATION);
    alert.setTitle(title);
    alert.setHeaderText(null);
    alert.setContentText(message);
    alert.showAndWait();
  }

  private void loadUserProfile() {
    loadContent("/DashboardFront/UserProfile.fxml");
  }

  private void loadUserData() {
    List<User> userList = userService.getAllUsers();
    ObservableList<User> observableUsers = FXCollections.observableArrayList(userList);
    userTable.setItems(observableUsers);
  }

  private void addDeleteButtonToTable() {
    Callback<TableColumn<User, Void>, TableCell<User, Void>> cellFactory = new Callback<>() {
      @Override
      public TableCell<User, Void> call(final TableColumn<User, Void> param) {
        return new TableCell<>() {
          private final Button btn = new Button("Delete");

          {
            btn.setStyle("-fx-background-color: red; -fx-text-fill: white;");

            btn.setOnAction(event -> {
              User user = getTableView().getItems().get(getIndex());
              int userId = user.getIdUser();

              // Confirm before deleting
              Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
              alert.setTitle("Confirmation");
              alert.setHeaderText("Suppression d'utilisateur");
              alert.setContentText("Voulez-vous vraiment supprimer cet utilisateur ?");
              alert.showAndWait().ifPresent(response -> {
                if (response == ButtonType.OK) {
                  boolean success = userService.deleteUserById(userId);
                  if (success) {
                    getTableView().getItems().remove(user);
                  } else {
                    showAlert("Erreur", "Impossible de supprimer l'utilisateur.");
                  }
                }
              });
            });
          }

          @Override
          protected void updateItem(Void item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
              setGraphic(null);
            } else {
              setGraphic(btn);
            }
          }
        };
      }
    };

    deleteColumn.setCellFactory(cellFactory);
  }
  private void addUpdateButtonToTable() {
    Callback<TableColumn<User, Void>, TableCell<User, Void>> cellFactory = new Callback<>() {
      @Override
      public TableCell<User, Void> call(final TableColumn<User, Void> param) {
        return new TableCell<>() {
          private final Button btn = new Button("Update");

          {
            btn.setStyle("-fx-background-color: blue; -fx-text-fill: white;");

            btn.setOnAction(event -> {
              User user = getTableView().getItems().get(getIndex());
                try {
                  UpdateUserController updateUserController = new UpdateUserController();
                  updateUserController.idUser = user.getIdUser();
                  updateUserController.handleUpdate(event);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });
          }

          @Override
          protected void updateItem(Void item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
              setGraphic(null);
            } else {
              setGraphic(btn);
            }
          }
        };
      }
    };

    updateColumn.setCellFactory(cellFactory);
  }
}
