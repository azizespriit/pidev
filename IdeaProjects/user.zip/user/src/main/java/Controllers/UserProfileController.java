package Controllers;

import entites.Client;
import entites.Admin;
import entites.Sessions;
import entites.User;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import services.ClientServiceImpl;
import services.AdminServiceImpl;

import java.util.Optional;

public class UserProfileController {

  @FXML
  private Label userNameLabel;
  @FXML
  private Label userEmailLabel;
  @FXML
  private Label userRoleLabel;
  @FXML
  private Label userExtraInfoLabel;

  @FXML
  public void initialize() {
    loadUserInfo();
  }

  private void loadUserInfo() {
    User user = Sessions.getCurrentUser(); // Récupérer l'utilisateur connecté
    if (user != null) {
      userNameLabel.setText("Nom : " + user.getFirstName() + " " + user.getLastName());
      userEmailLabel.setText("Email : " + user.getEmail());
      userRoleLabel.setText("Rôle : " + user.getRoles());

      // Vérifier si c'est un client ou un admin et récupérer les infos spécifiques
      if (user.getRoles().equalsIgnoreCase("client")) {
        ClientServiceImpl clientService = new ClientServiceImpl();
        Optional<Client> client = clientService.getClientByUserId(user.getIdUser());
        client.ifPresent(o -> userExtraInfoLabel.setText("Expérience : " + o.getYearsOfExperience() + " ans | Événements : " + o.getNumberOfEventsOrganized()));
      } else if (user.getRoles().equalsIgnoreCase("admin")) {
        AdminServiceImpl adminService = new AdminServiceImpl();
        Optional<Admin> admin = adminService.getAdminByUserId(user.getIdUser());
        admin.ifPresent(p -> userExtraInfoLabel.setText("Spécialité : " + p.getSpeciality()));
      } else {
        userExtraInfoLabel.setText("Aucune information supplémentaire.");
      }
    } else {
      userNameLabel.setText("Utilisateur inconnu");
      userEmailLabel.setText("Aucun email");
      userRoleLabel.setText("Rôle inconnu");
      userExtraInfoLabel.setText("Aucune information disponible.");
    }
  }
}
