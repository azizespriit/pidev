package services;

import entites.Admin;
import entites.User;

import java.sql.SQLException;

public interface AdminService extends UserService {
  void registerAdmin(Admin admin) throws SQLException;


  int register(User user) throws SQLException;

}
