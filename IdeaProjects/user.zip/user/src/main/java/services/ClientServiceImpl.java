package services;

import entites.Client;
import entites.User;
import org.mindrot.jbcrypt.BCrypt;
import utils.dataSource;
import java.sql.*;
import java.util.Optional;

public class ClientServiceImpl implements ClientService {

  private Connection connection;

  public ClientServiceImpl() {
    this.connection = dataSource.getInstance().getConnection();
  }
  @Override

  public void registerClient(Client client) throws SQLException {
    String sql = "INSERT INTO client (user_id, yearsOfExperience, numberOfEventsOrganized) VALUES (?, ?, ?)";

    try {
      connection.setAutoCommit(false);

      // Enregistrer l'utilisateur dans la table 'user'
      String userSql = "INSERT INTO user (cin, lastName, firstName, gender, phone, roles, email, password) " +
              "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
      try (PreparedStatement pstmtUser = connection.prepareStatement(userSql, Statement.RETURN_GENERATED_KEYS)) {
        pstmtUser.setString(1, client.getCin());
        pstmtUser.setString(2, client.getLastName());
        pstmtUser.setString(3, client.getFirstName());
        pstmtUser.setString(4, client.getGender());
        pstmtUser.setString(5, client.getPhone());
        pstmtUser.setString(6, client.getRoles());
        pstmtUser.setString(7, client.getEmail());

        // Hasher le mot de passe
        String hashedPassword = BCrypt.hashpw(client.getPassword(), BCrypt.gensalt(12));
        System.out.println("Mot de passe haché (client) : " + hashedPassword);
        pstmtUser.setString(8, hashedPassword);

        pstmtUser.executeUpdate();

        ResultSet rs = pstmtUser.getGeneratedKeys();
        int generatedUserId = 0;
        if (rs.next()) {
          generatedUserId = rs.getInt(1);
        }

        // Enregistrer l'client avec l'ID utilisateur
        try (PreparedStatement pstmtClient = connection.prepareStatement(sql)) {
          pstmtClient.setInt(1, generatedUserId);
          pstmtClient.setInt(2, client.getYearsOfExperience());
          pstmtClient.setInt(3, client.getNumberOfEventsOrganized());

          pstmtClient.executeUpdate();
          connection.commit();
          System.out.println("Client enregistré avec succès !");
        }
      } catch (SQLException e) {
        connection.rollback();
        throw e;
      }
    } catch (SQLException e) {
      System.err.println("Erreur lors de l'enregistrement de l'client : " + e.getMessage());
      throw e;
    } finally {
      connection.setAutoCommit(true);
    }
  }


  @Override
  public int register(User user) throws SQLException {
    return 0;
  }

  @Override
  public Optional<User> login(String email, String password) {
    return Optional.empty();
  }

  @Override
  public boolean isAccountLocked(String email) {
    return false;
  }

  @Override
  public void increaseFailedAttempts(String email) {

  }

  @Override
  public void resetFailedAttempts(String email) {

  }

  @Override
  public void lockAccount(String email) {

  }
  public Optional<Client> getClientByUserId(int userId) {
    String query = "SELECT * FROM client WHERE user_id = ?";
    try (PreparedStatement ps = connection.prepareStatement(query)) {
      ps.setInt(1, userId);
      ResultSet rs = ps.executeQuery();

      if (rs.next()) {
        return Optional.of(new Client(
                userId,
                rs.getInt("yearsOfExperience"),
                rs.getInt("numberOfEventsOrganized")
        ));
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return Optional.empty();
  }
}
