package services;

import entites.Admin;
import entites.User;
import org.mindrot.jbcrypt.BCrypt;
import utils.dataSource;

import java.sql.*;
import java.util.Optional;

public class AdminServiceImpl implements AdminService {
  private Connection connection;

  public AdminServiceImpl() {
    this.connection = dataSource.getInstance().getConnection();
  }
  @Override
  public void registerAdmin(Admin Admin) throws SQLException {
    String userSql = "INSERT INTO user (cin, lastName, firstName, gender, phone, roles, email, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    String AdminSql = "INSERT INTO Admin (user_id, speciality, experience) VALUES (?, ?, ?)";

    try {
      connection.setAutoCommit(false);

      try (PreparedStatement pstmtUser = connection.prepareStatement(userSql, Statement.RETURN_GENERATED_KEYS)) {
        pstmtUser.setString(1, Admin.getCin());
        pstmtUser.setString(2, Admin.getLastName());
        pstmtUser.setString(3, Admin.getFirstName());
        pstmtUser.setString(4, Admin.getGender());
        pstmtUser.setString(5, Admin.getPhone());
        pstmtUser.setString(6, Admin.getRoles());
        pstmtUser.setString(7, Admin.getEmail());

        // Hasher le mot de passe
        String hashedPassword = BCrypt.hashpw(Admin.getPassword(), BCrypt.gensalt(12));
        System.out.println("Mot de passe haché (Admin) : " + hashedPassword);
        pstmtUser.setString(8, hashedPassword);

        pstmtUser.executeUpdate();

        ResultSet rs = pstmtUser.getGeneratedKeys();
        int generatedUserId = 0;
        if (rs.next()) {
          generatedUserId = rs.getInt(1);
        }

        try (PreparedStatement pstmtAdmin = connection.prepareStatement(AdminSql)) {
          pstmtAdmin.setInt(1, generatedUserId);
          pstmtAdmin.setString(2, Admin.getSpeciality());
          pstmtAdmin.setString(3, Admin.getExperience());

          pstmtAdmin.executeUpdate();
          connection.commit();
          System.out.println("Admin enregistré avec succès !");
        }
      } catch (SQLException e) {
        connection.rollback();
        throw e;
      }
    } catch (SQLException e) {
      System.err.println("Erreur lors de l'enregistrement du Admin : " + e.getMessage());
      throw e;
    } finally {
      connection.setAutoCommit(true);
    }
  }

  @Override
  public int register(User user) throws SQLException {
    return 0;
  }

  @Override
  public Optional<User> login(String email, String password) {
    return Optional.empty();
  }

  @Override
  public boolean isAccountLocked(String email) {
    return false;
  }

  @Override
  public void increaseFailedAttempts(String email) {

  }

  @Override
  public void resetFailedAttempts(String email) {

  }

  @Override
  public void lockAccount(String email) {

  }
  public Optional<Admin> getAdminByUserId(int userId) {
    String query = "SELECT * FROM Admin WHERE user_id = ?";
    try (PreparedStatement ps = connection.prepareStatement(query)) {
      ps.setInt(1, userId);
      ResultSet rs = ps.executeQuery();

      if (rs.next()) {
        return Optional.of(new Admin(
          userId,
          rs.getString("speciality"),
          rs.getString("experience")
        ));
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return Optional.empty();
  }
}
