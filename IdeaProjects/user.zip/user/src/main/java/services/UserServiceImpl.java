package services;
import javafx.scene.control.TableCell;
import services.IService;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import entites.User;
import org.mindrot.jbcrypt.BCrypt;
import utils.dataSource;

import javax.swing.table.TableColumn;
import java.time.LocalDateTime;
import java.util.Optional;


public class UserServiceImpl implements UserService {

  private Connection connection;

  public UserServiceImpl() {
    this.connection = dataSource.getInstance().getConnection();
  }

  public List<User> getAllUsers() {
    List<User> users = new ArrayList<>();
    String query = "SELECT * FROM user"; // Adjust based on your table structure

    try (PreparedStatement ps = connection.prepareStatement(query)) {
      ResultSet rs = ps.executeQuery();

      while (rs.next()) {
        User user = new User();
        user.setIdUser(rs.getInt("id_user"));
        user.setEmail(rs.getString("email"));
        user.setFirstName(rs.getString("firstName"));
        user.setLastName(rs.getString("lastName"));
        user.setRoles(rs.getString("roles"));
        user.setCin(rs.getString("cin"));
        user.setGender(rs.getString("gender"));
        user.setPhone(rs.getString("phone"));
        users.add(user);
      }

    } catch (SQLException e) {
      e.printStackTrace();
    }
    return users;
  }

  @Override
  public int register(User user) throws SQLException {
    String sql = "INSERT INTO user (cin, lastName, firstName, gender, phone, roles, email, password) " +
      "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
      pstmt.setString(1, user.getCin());
      pstmt.setString(2, user.getLastName());
      pstmt.setString(3, user.getFirstName());
      pstmt.setString(4, user.getGender());
      pstmt.setString(5, user.getPhone());
      pstmt.setString(6, user.getRoles());
      pstmt.setString(7, user.getEmail());

      String hashedPassword = BCrypt.hashpw(user.getPassword(), BCrypt.gensalt(12));
      System.out.println("Mot de passe haché : " + hashedPassword); // Vérification
      pstmt.setString(8, hashedPassword);

      pstmt.executeUpdate();
      System.out.println("Utilisateur enregistré avec succès !");
    } catch (SQLException e) {
      System.err.println("Erreur lors de l'enregistrement de l'utilisateur : " + e.getMessage());
      throw e;
    }
    return 0;
  }

////////////////////////// *****************************///////////////////
@Override
public Optional<User> login(String email, String password) {
  if (isAccountLocked(email)) {
    System.out.println("Compte bloqué. Réessayez plus tard.");
    return Optional.empty();
  }

  String query = "SELECT * FROM user WHERE email = ?";
  try (PreparedStatement ps = connection.prepareStatement(query)) {
    ps.setString(1, email);
    ResultSet rs = ps.executeQuery();

    if (rs.next()) {
      String storedHashedPassword = rs.getString("password");

      // Vérification du mot de passe avec BCrypt
      if (BCrypt.checkpw(password, storedHashedPassword)) {
        resetFailedAttempts(email);
        return Optional.of(new User(
          rs.getInt("id_user"),
          rs.getString("cin"),
          rs.getString("lastName"),
          rs.getString("firstName"),
          rs.getString("gender"),
          rs.getString("phone"),
          rs.getString("roles"),
          rs.getString("email"),
          rs.getString("password"),
          rs.getBoolean("isLocked"),
          rs.getInt("failedAttempts"),
          rs.getTimestamp("lockoutTime") != null ? rs.getTimestamp("lockoutTime").toLocalDateTime() : null
        ));
      } else {
        increaseFailedAttempts(email);
        return Optional.empty();
      }
    }
  } catch (Exception e) {
    e.printStackTrace();
  }
  return Optional.empty();
}

  @Override
  public boolean isAccountLocked(String email) {
    String query = "SELECT isLocked, lockoutTime FROM user WHERE email = ?";
    try (PreparedStatement ps = connection.prepareStatement(query)) {
      ps.setString(1, email);
      ResultSet rs = ps.executeQuery();
      if (rs.next()) {
        boolean isLocked = rs.getBoolean("isLocked");
        LocalDateTime lockoutTime = rs.getTimestamp("lockoutTime") != null
          ? rs.getTimestamp("lockoutTime").toLocalDateTime()
          : null;

        if (isLocked && lockoutTime != null) {
          if (lockoutTime.plusMinutes(15).isBefore(LocalDateTime.now())) {
            unlockAccount(email);
            return false;
          }
          return true;
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return false;
  }

  private void unlockAccount(String email) {
    String query = "UPDATE user SET isLocked = false, failedAttempts = 0, lockoutTime = NULL WHERE email = ?";
    try (PreparedStatement ps = connection.prepareStatement(query)) {
      ps.setString(1, email);
      ps.executeUpdate();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Override
  public void increaseFailedAttempts(String email) {
    String query = "UPDATE user SET failedAttempts = failedAttempts + 1 WHERE email = ?";
    try (PreparedStatement ps = connection.prepareStatement(query)) {
      ps.setString(1, email);
      ps.executeUpdate();
    } catch (Exception e) {
      e.printStackTrace();
    }

    String checkAttempts = "SELECT failedAttempts FROM user WHERE email = ?";
    try (PreparedStatement ps = connection.prepareStatement(checkAttempts)) {
      ps.setString(1, email);
      ResultSet rs = ps.executeQuery();
      if (rs.next() && rs.getInt("failedAttempts") >= 3) {
        lockAccount(email);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Override
  public void resetFailedAttempts(String email) {
    String query = "UPDATE user SET failedAttempts = 0 WHERE email = ?";
    try (PreparedStatement ps = connection.prepareStatement(query)) {
      ps.setString(1, email);
      ps.executeUpdate();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Override
  public void lockAccount(String email) {
    String query = "UPDATE user SET isLocked = true, lockoutTime = ? WHERE email = ?";
    try (PreparedStatement ps = connection.prepareStatement(query)) {
      ps.setTimestamp(1, Timestamp.valueOf(LocalDateTime.now()));
      ps.setString(2, email);
      ps.executeUpdate();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
  public Optional<User> getUserByEmail(String email) {
    String query = "SELECT * FROM user WHERE email = ?";
    try (PreparedStatement ps = connection.prepareStatement(query)) {
      ps.setString(1, email);
      ResultSet rs = ps.executeQuery();

      if (rs.next()) {
        return Optional.of(new User(
          rs.getInt("id_user"),
          rs.getString("cin"),
          rs.getString("lastName"),
          rs.getString("firstName"),
          rs.getString("gender"),
          rs.getString("phone"),
          rs.getString("roles"),
          rs.getString("email"),
          rs.getString("password"),
          rs.getBoolean("isLocked"),
          rs.getInt("failedAttempts"),
          rs.getTimestamp("lockoutTime") != null ? rs.getTimestamp("lockoutTime").toLocalDateTime() : null
        ));
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return Optional.empty();
  }

  public boolean deleteUserById(int userId) {
    String query = "DELETE FROM user WHERE id_user = ?";
    try (PreparedStatement stmt = connection.prepareStatement(query)) {
      stmt.setInt(1, userId);
      return stmt.executeUpdate() > 0;
    } catch (SQLException e) {
      e.printStackTrace();
      return false;
    }
  }
  public boolean updateUser(User user) {
    String updateQuery = "UPDATE user SET firstName = ?, lastName = ?, email = ? WHERE id_user = ?";

    try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {

      preparedStatement.setString(1, user.getFirstName());
      preparedStatement.setString(2, user.getLastName());
      preparedStatement.setString(3, user.getEmail());
      preparedStatement.setInt(4, user.getIdUser());

      int rowsAffected = preparedStatement.executeUpdate();
      return rowsAffected > 0; // Return true if at least one row was updated

    } catch (SQLException e) {
      e.printStackTrace();
      return false; // Return false in case of any exceptions
    }
  }

  public boolean storeResetCodeInDB(String email, String resetCode) {
    String query = "INSERT INTO GeneratedCodes (id, code,email) VALUES (null,?,?)";
    try (PreparedStatement ps = connection.prepareStatement(query)) {
      ps.setString(1, resetCode);
      ps.setString(2, email);
      int updatedRows = ps.executeUpdate();
      return updatedRows > 0; // ✅ Return true if insertion was successful
    } catch (SQLException e) {
      e.printStackTrace();
      return false;
    }
  }

  public String getLastGeneratedCodeFromDB() {
    String query = "SELECT code FROM GeneratedCodes ORDER BY id DESC LIMIT 1"; // Assuming 'id' is an auto-increment field
    try (PreparedStatement ps = connection.prepareStatement(query);
         ResultSet rs = ps.executeQuery()) {

      if (rs.next()) {
        return rs.getString("code");
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return null;
  }

  public String getLastEmailFromDB() {
    String query = "SELECT email FROM GeneratedCodes ORDER BY id DESC LIMIT 1"; // Assuming 'id' is an auto-increment field
    try (PreparedStatement ps = connection.prepareStatement(query);
         ResultSet rs = ps.executeQuery()) {

      if (rs.next()) {
        return rs.getString("email");
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return null;
  }


  public boolean updatePasswordInDB(String email, String newPass) {
    // Hash the new password
    String hashedPassword = BCrypt.hashpw(newPass, BCrypt.gensalt());

    String query = "UPDATE User SET password = ? WHERE email = ?"; // Adjust the table and column names as needed
    try (PreparedStatement ps = connection.prepareStatement(query)) {
      ps.setString(1, hashedPassword); // Set the hashed password
      ps.setString(2, email);           // Set email for the specific user
      int updatedRows = ps.executeUpdate();
      return updatedRows > 0; // Return true if update was successful
    } catch (SQLException e) {
      e.printStackTrace();
      return false;
    }
  }

}
