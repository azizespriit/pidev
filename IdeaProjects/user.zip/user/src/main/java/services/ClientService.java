package services;

import entites.Client;
import java.sql.SQLException;

public interface ClientService extends UserService {
  void registerClient(Client client) throws SQLException;


}
