package entites;


import java.time.LocalDateTime;

public class Admin extends User {
  private int idAdmin;
  private String speciality;
  private String experience;

  // Constructeur complet avec tous les attributs
  public Admin(int idUser, String cin, String lastName, String firstName, String gender, String phone, String roles,
               String email, String password, Boolean isLocked, Integer failedAttempts, LocalDateTime lockoutTime,
               int idAdmin, String speciality, String experience) {
    super(idUser, cin, lastName, firstName, gender, phone, roles, email, password, isLocked, failedAttempts, lockoutTime);
    this.idAdmin = idAdmin;
    this.speciality = speciality;
    this.experience = experience;
  }

  // Constructeur sans idAdmin (pour un nouveau Admin)
  public Admin(String cin, String lastName, String firstName, String gender, String phone, String roles,
               String email, String password, Boolean isLocked, Integer failedAttempts, LocalDateTime lockoutTime,
               String speciality, String experience) {
    super(cin, lastName, firstName, gender, phone, roles, email, password, isLocked, failedAttempts, lockoutTime);
    this.speciality = speciality;
    this.experience = experience;
  }

  // Constructeur sans gestion du verrouillage
  public Admin(String cin, String lastName, String firstName, String gender, String phone, String roles,
               String email, String password, String speciality, String experience) {
    super(cin, lastName, firstName, gender, phone, roles, email, password);
    this.speciality = speciality;
    this.experience = experience;
  }

  public Admin(int userId, String speciality, String experience) {
  }

  public int getIdAdmin() {
    return idAdmin;
  }

  public void setIdAdmin(int idAdmin) {
    this.idAdmin = idAdmin;
  }

  public String getSpeciality() {
    return speciality;
  }

  public void setSpeciality(String speciality) {
    this.speciality = speciality;
  }

  public String getExperience() {
    return experience;
  }

  public void setExperience(String experience) {
    this.experience = experience;
  }
}
