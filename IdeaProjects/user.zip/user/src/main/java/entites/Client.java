package entites;

import java.time.LocalDateTime;

public class Client extends User {
  private int idClient;
  private int yearsOfExperience;
  private int numberOfEventsOrganized;

  // Constructeur complet avec tous les attributs
  public Client(int idUser, String cin, String lastName, String firstName, String gender, String phone, String roles,
                String email, String password, Boolean isLocked, Integer failedAttempts, LocalDateTime lockoutTime,
                int idClient, int yearsOfExperience, int numberOfEventsOrganized) {
    super(idUser, cin, lastName, firstName, gender, phone, roles, email, password, isLocked, failedAttempts, lockoutTime);
    this.idClient = idClient;
    this.yearsOfExperience = yearsOfExperience;
    this.numberOfEventsOrganized = numberOfEventsOrganized;
  }

  // Constructeur sans idClient (pour un nouvel Client)
  public Client(String cin, String lastName, String firstName, String gender, String phone, String roles,
                String email, String password, Boolean isLocked, Integer failedAttempts, LocalDateTime lockoutTime,
                int yearsOfExperience, int numberOfEventsOrganized) {
    super(cin, lastName, firstName, gender, phone, roles, email, password, isLocked, failedAttempts, lockoutTime);
    this.yearsOfExperience = yearsOfExperience;
    this.numberOfEventsOrganized = numberOfEventsOrganized;
  }

  // Constructeur sans gestion du verrouillage
  public Client(String cin, String lastName, String firstName, String gender, String phone, String roles,
                String email, String password, int yearsOfExperience, int numberOfEventsOrganized) {
    super(cin, lastName, firstName, gender, phone, roles, email, password);
    this.yearsOfExperience = yearsOfExperience;
    this.numberOfEventsOrganized = numberOfEventsOrganized;
  }

  public Client(int idUser, int yearsOfExperience, int eventsOrganized) {
    super();
  }

  public int getIdClient() {
    return idClient;
  }

  public void setIdClient(int idClient) {
    this.idClient = idClient;
  }

  public int getYearsOfExperience() {
    return yearsOfExperience;
  }

  public void setYearsOfExperience(int yearsOfExperience) {
    this.yearsOfExperience = yearsOfExperience;
  }

  public int getNumberOfEventsOrganized() {
    return numberOfEventsOrganized;
  }

  public void setNumberOfEventsOrganized(int numberOfEventsOrganized) {
    this.numberOfEventsOrganized = numberOfEventsOrganized;
  }

  @Override
  public String toString() {
    return "Client{" +
      "idClient=" + idClient +
      ", yearsOfExperience=" + yearsOfExperience +
      ", numberOfEventsOrganized=" + numberOfEventsOrganized +
      '}';
  }
}
